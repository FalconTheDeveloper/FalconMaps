let map;
let routingControl = null;

function initMap() {
  // Initialize the map centered on a default location
  map = L.map('map', {
    center: [40.7128, -74.0060],  // New York City coordinates
    zoom: 13,
    zoomControl: false  // We'll use our custom zoom controls
  });

  // Add the tile layer (OpenStreetMap)
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19
  }).addTo(map);

  // Add event listeners for custom controls
  document.querySelector('.zoom-in').addEventListener('click', () => {
    map.zoomIn();
  });

  document.querySelector('.zoom-out').addEventListener('click', () => {
    map.zoomOut();
  });

  // Add search functionality
  const searchInput = document.getElementById('search');
  searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      searchLocation(searchInput.value);
    }
  });

  document.querySelector('.search-button').addEventListener('click', () => {
    searchLocation(searchInput.value);
  });

  // Add layers button functionality
  document.querySelector('.layers').addEventListener('click', toggleLayers);

  // Update input event listeners for route locations
  document.getElementById('start-location').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      document.getElementById('start-town').focus();
    }
  });

  document.getElementById('start-town').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      document.getElementById('start-state').focus();
    }
  });

  document.getElementById('start-state').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      document.getElementById('end-location').focus();
    }
  });

  document.getElementById('end-location').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      document.getElementById('end-town').focus();
    }
  });

  document.getElementById('end-town').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      document.getElementById('end-state').focus();
    }
  });

  document.getElementById('end-state').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      calculateRoute();
    }
  });
}

function searchLocation(query) {
  // Using OpenStreetMap Nominatim API for geocoding
  fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`)
    .then(response => response.json())
    .then(data => {
      if (data.length > 0) {
        const location = data[0];
        map.setView([location.lat, location.lon], 13);
        L.marker([location.lat, location.lon]).addTo(map);
      }
    })
    .catch(error => console.error('Error:', error));
}

function toggleDirectionsPanel() {
  const panel = document.getElementById('directions-panel');
  panel.classList.toggle('active');
}

async function getCoordinates(location, state, town) {
  if (!location || !state || !town) {
    throw new Error('Location, state, and town are all required');
  }
  
  const query = `${location}, ${town}, ${state}, USA`;
  const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`);
  const data = await response.json();
  
  if (data.length > 0) {
    // Try to find a result that matches both state and town
    const townStateResult = data.find(item => {
      const displayName = item.display_name.toLowerCase();
      return displayName.includes(state.toLowerCase()) && 
             displayName.includes(town.toLowerCase());
    });
    
    if (townStateResult) {
      return [parseFloat(townStateResult.lat), parseFloat(townStateResult.lon)];
    }
    throw new Error(`Location not found in ${town}, ${state}`);
  }
  throw new Error('Location not found');
}

async function calculateRoute() {
  const startLocation = document.getElementById('start-location').value;
  const startTown = document.getElementById('start-town').value;
  const startState = document.getElementById('start-state').value;
  const endLocation = document.getElementById('end-location').value;
  const endTown = document.getElementById('end-town').value;
  const endState = document.getElementById('end-state').value;

  // Reset error messages
  document.querySelectorAll('.error-message').forEach(el => el.classList.remove('show'));

  // Validate inputs
  if (!startLocation || !startState || !startTown || !endLocation || !endState || !endTown) {
    if (!startLocation || !startState || !startTown) {
      document.getElementById('start-error').classList.add('show');
    }
    if (!endLocation || !endState || !endTown) {
      document.getElementById('end-error').classList.add('show');
    }
    return;
  }

  try {
    const startCoords = await getCoordinates(startLocation, startState, startTown);
    const endCoords = await getCoordinates(endLocation, endState, endTown);

    // Remove existing routing control if it exists
    if (routingControl) {
      map.removeControl(routingControl);
    }

    // Create new routing control
    routingControl = L.Routing.control({
      waypoints: [
        L.latLng(startCoords[0], startCoords[1]),
        L.latLng(endCoords[0], endCoords[1])
      ],
      routeWhileDragging: true,
      showAlternatives: true,
      lineOptions: {
        styles: [{ color: '#4285f4', weight: 6 }]
      }
    }).addTo(map);

    // Fit the map to show the entire route
    routingControl.on('routesfound', function(e) {
      const routes = e.routes;
      const bounds = L.latLngBounds(routes[0].coordinates);
      map.fitBounds(bounds, { padding: [50, 50] });
    });

  } catch (error) {
    console.error('Error calculating route:', error);
    if (error.message.includes('start')) {
      document.getElementById('start-error').classList.add('show');
    } else if (error.message.includes('end')) {
      document.getElementById('end-error').classList.add('show');
    } else {
      document.getElementById('directions-result').innerHTML = 
        `<div class="route-instruction">Error: ${error.message}</div>`;
    }
  }
}

function toggleLayers() {
  // Add layer switching functionality here
  alert('Layer switching would be implemented here!');
}

// Initialize the map when the page loads
window.addEventListener('load', initMap);